//
//  encryChar.h
//  encryDemo
//
//  Created by 周经伟 on 15/12/19.
//  Copyright © 2015年 packy. All rights reserved.
//

#ifndef encryChar_h
#define encryChar_h

#include <stdio.h>

#endif /* encryChar_h */
char* base64_encode(const char *data);
char* base64_decode(const char *bdata);